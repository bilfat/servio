<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Resources\ProviderOrderResource;
use App\Models\ServiceOrder;
use App\Services\ProviderDispatchService;
use App\Support\ApiResponse;
use App\Support\AuthenticatedActor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProviderOrderController
{
    public function __construct(
        private readonly ProviderDispatchService $dispatchService,
    ) {}

    public function index(Request $request): JsonResponse
    {
        /** @var AuthenticatedActor $actor */
        $actor = $request->attributes->get('actor');

        $query = ServiceOrder::query()
            ->with(['booking.activeAssignment.attempt', 'visit'])
            ->where('provider_org_id', $actor->organizationId)
            ->orderBy('created_at', 'desc');

        if ($request->has('status') && $request->input('status') !== 'ALL') {
            $query->where('status', $request->input('status'));
        }

        // Robust pagination validation: clamp strictly between 1 and 50
        $rawPerPage = $request->input('per_page', 15);
        if (!is_numeric($rawPerPage) || (int) $rawPerPage < 1) {
            $perPage = 15;
        } else {
            $perPage = min((int) $rawPerPage, 50);
        }

        $rawPage = $request->input('page', 1);
        $page = (!is_numeric($rawPage) || (int) $rawPage < 1) ? 1 : (int) $rawPage;

        $orders = $query->paginate(perPage: $perPage, page: $page);

        return ApiResponse::success(
            ProviderOrderResource::collection($orders),
            200,
            [
                'pagination' => [
                    'current_page' => $orders->currentPage(),
                    'per_page' => $orders->perPage(),
                    'total' => $orders->total(),
                    'last_page' => $orders->lastPage(),
                ],
            ]
        );
    }

    public function show(Request $request, string $id): JsonResponse
    {
        /** @var AuthenticatedActor $actor */
        $actor = $request->attributes->get('actor');

        // Scoped query: Provider can ONLY query orders assigned to their organization
        $query = ServiceOrder::with(['booking.activeAssignment.attempt', 'visit', 'execution', 'issues'])
            ->where('id', $id);

        if (!$actor->isAdmin()) {
            $query->where('provider_org_id', $actor->organizationId);
        }

        $order = $query->first();

        if (!$order) {
            return ApiResponse::error(
                'ORDER_JASA_NOT_FOUND',
                'Pesanan jasa tidak ditemukan.',
                404
            );
        }

        return ApiResponse::success(new ProviderOrderResource($order));
    }

    /**
     * Provider assign worker to order
     */
    public function assignWorker(Request $request, string $id): JsonResponse
    {
        /** @var AuthenticatedActor $actor */
        $actor = $request->attributes->get('actor');

        $validated = $request->validate([
            'worker_id' => 'required|string',
        ]);

        $request->attributes->set('idempotency_has_side_effect', true);

        $attempt = $this->dispatchService->assignWorker($actor, $id, (string) $validated['worker_id']);

        return ApiResponse::success([
            'attempt_id' => $attempt->id,
            'booking_id' => $attempt->booking_id,
            'order_id' => $attempt->order_id,
            'worker_id' => $attempt->worker_id,
            'status' => $attempt->status,
            'assigned_at' => $attempt->assigned_at?->toISOString(),
            'response_due_at' => $attempt->response_due_at?->toISOString(),
            'message' => 'Teknisi berhasil ditugaskan. Menunggu respons teknisi (SLA 30 menit).',
        ], 200);
    }
}
