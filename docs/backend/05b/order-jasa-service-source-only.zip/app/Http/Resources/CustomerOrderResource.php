<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ServiceOrder;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin ServiceOrder
 */
class CustomerOrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $booking = $this->booking;
        $activeAssignment = $booking?->activeAssignment;
        $attempt = $activeAssignment?->attempt;

        // V2 Business Lock & Security Rule:
        // Worker identity MUST BE ABSENT from customer serialization before assignment is ACCEPTED!
        $isWorkerAccepted = $attempt && $attempt->status === 'ACCEPTED';

        $workerData = null;
        if ($isWorkerAccepted) {
            $workerData = [
                'worker_id' => $attempt->worker_id,
                'status' => $attempt->status,
                'accepted_at' => $attempt->accepted_at?->toIso8601String(),
                'membership_snapshot' => $attempt->worker_membership_snapshot,
            ];
        }

        return [
            'id' => $this->id,
            'order_no' => $this->order_no,
            'customer_id' => $this->customer_id,
            'provider_org_id' => $this->provider_org_id,
            'service_offering_id' => $this->service_offering_id,
            'service_snapshot' => $this->service_snapshot,
            'recipient_snapshot' => $this->recipient_snapshot,
            'address_snapshot' => $this->address_snapshot,
            'complaint_text' => $this->complaint_text,
            'symptoms' => $this->symptoms_json,
            'diagnosis_fee_idr' => $this->diagnosis_fee_idr,
            'diagnosis_fee_exemption_type' => $this->diagnosis_fee_exemption_type,
            'status' => $this->status,
            'phase' => $this->phase,
            'cancel_reason_code' => $this->cancel_reason_code,
            'original_order_id' => $this->original_order_id,
            'version' => $this->version,
            'schedule' => $booking ? [
                'start_at' => $booking->scheduled_start_at?->toIso8601String(),
                'end_at' => $booking->scheduled_end_at?->toIso8601String(),
                'timezone' => $booking->timezone,
                'status' => $booking->status,
            ] : null,
            'assigned_worker' => $workerData, // Masked if not ACCEPTED!
            'completed_at' => $this->completed_at?->toIso8601String(),
            'cancelled_at' => $this->cancelled_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
