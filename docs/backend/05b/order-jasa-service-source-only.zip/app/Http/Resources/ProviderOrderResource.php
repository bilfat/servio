<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ServiceOrder;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin ServiceOrder
 */
class ProviderOrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $booking = $this->booking;
        $activeAssignment = $booking?->activeAssignment;
        $attempt = $activeAssignment?->attempt;

        return [
            'id' => $this->id,
            'order_no' => $this->order_no,
            'customer_id' => $this->customer_id,
            'provider_org_id' => $this->provider_org_id,
            'service_offering_id' => $this->service_offering_id,
            'service_snapshot' => $this->service_snapshot,
            'recipient_snapshot' => $this->recipient_snapshot,
            'address_snapshot' => $this->address_snapshot,
            'complaint_text' => $this->complaint_text,
            'symptoms' => $this->symptoms_json,
            'diagnosis_fee_idr' => $this->diagnosis_fee_idr,
            'status' => $this->status,
            'phase' => $this->phase,
            'cancel_reason_code' => $this->cancel_reason_code,
            'version' => $this->version,
            'schedule' => $booking ? [
                'start_at' => $booking->scheduled_start_at?->toIso8601String(),
                'end_at' => $booking->scheduled_end_at?->toIso8601String(),
                'timezone' => $booking->timezone,
                'status' => $booking->status,
            ] : null,
            'active_assignment' => $attempt ? [
                'attempt_id' => $attempt->id,
                'worker_id' => $attempt->worker_id,
                'status' => $attempt->status,
                'assigned_at' => $attempt->assigned_at?->toIso8601String(),
                'response_due_at' => $attempt->response_due_at?->toIso8601String(),
                'accepted_at' => $attempt->accepted_at?->toIso8601String(),
            ] : null,
            'visit' => $this->visit ? [
                'status' => $this->visit->status,
                'worker_id' => $this->visit->worker_id,
                'arrived_at' => $this->visit->arrived_at?->toIso8601String(),
            ] : null,
            'completed_at' => $this->completed_at?->toIso8601String(),
            'cancelled_at' => $this->cancelled_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
