<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Domain\Shipping\DeliverySettingService;
use App\Infrastructure\Identity\IdentityAddressClient;
use App\Models\MerchantDeliverySetting;
use App\Support\ApiResponse;
use App\Support\AuthenticatedActor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MerchantDeliverySettingController extends Controller
{
    public function __construct(
        protected DeliverySettingService $deliverySettingService,
        protected IdentityAddressClient $identityClient
    ) {}

    public function show(Request $request): JsonResponse
    {
        /** @var AuthenticatedActor $actor */
        $actor = $request->attributes->get('actor');

        $setting = MerchantDeliverySetting::where('merchant_org_id', $actor->organizationId)
            ->with(['activeTiers'])
            ->first();

        if (!$setting) {
            // Default response if not configured yet
            return ApiResponse::success([
                'merchant_org_id' => $actor->organizationId,
                'is_enabled' => false,
                'maximum_distance_km' => 25.0,
                'distance_method' => 'HAVERSINE',
                'operational_note' => null,
                'version' => 0,
                'tiers' => [],
            ], 'DELIVERY_SETTINGS_DEFAULT');
        }

        return ApiResponse::success([
            'id' => $setting->id,
            'merchant_org_id' => $setting->merchant_org_id,
            'is_enabled' => $setting->is_enabled,
            'origin_reference_id' => $setting->origin_reference_id,
            'origin_lat' => $setting->origin_lat,
            'origin_lng' => $setting->origin_lng,
            'origin_region_code' => $setting->origin_region_code,
            'maximum_distance_km' => $setting->maximum_distance_km,
            'distance_method' => $setting->distance_method,
            'operational_note' => $setting->operational_note,
            'version' => $setting->version,
            'tiers' => $setting->activeTiers,
        ], 'DELIVERY_SETTINGS_LOADED');
    }

    public function update(Request $request): JsonResponse
    {
        /** @var AuthenticatedActor $actor */
        $actor = $request->attributes->get('actor');

        $validated = $request->validate([
            'is_enabled' => 'required|boolean',
            'maximum_distance_km' => 'required|numeric|min:0.1|max:100',
            'tiers' => 'required|array|min:1',
            'tiers.*.from_km' => 'required|numeric|min:0',
            'tiers.*.to_km' => 'required|numeric|gt:tiers.*.from_km',
            'tiers.*.shipping_fee_idr' => 'required|integer|min:0',
            'tiers.*.position' => 'nullable|integer',
            'operational_note' => 'nullable|string|max:1000',
            'expected_version' => 'nullable|integer',
        ]);

        // Official origin coordinates must be fetched from Identity Service (do not accept arbitrary coordinates from client)
        $officialOrigin = $this->identityClient->getMerchantOrigin($actor->organizationId);

        $setting = $this->deliverySettingService->updateSettings(
            merchantOrgId: $actor->organizationId,
            isEnabled: (bool) $validated['is_enabled'],
            maxDistanceKm: (float) $validated['maximum_distance_km'],
            tiers: $validated['tiers'],
            operationalNote: $validated['operational_note'] ?? null,
            actorId: $actor->id,
            expectedVersion: isset($validated['expected_version']) ? (int) $validated['expected_version'] : null,
            officialOrigin: $officialOrigin
        );

        return ApiResponse::success([
            'id' => $setting->id,
            'merchant_org_id' => $setting->merchant_org_id,
            'is_enabled' => $setting->is_enabled,
            'maximum_distance_km' => $setting->maximum_distance_km,
            'version' => $setting->version,
            'tiers' => $setting->activeTiers,
        ], 'DELIVERY_SETTINGS_UPDATED');
    }
}
